#!/bin/bash

THEME_NAME="ciel-classroom"
THEME_DIR="/boot/grub/themes/$THEME_NAME"

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (use sudo)."
  exit 1
fi

echo "Removing Ciel Classroom theme..."

rm -rf "$THEME_DIR"

# Comment out the GRUB_THEME line
sed -i 's|^GRUB_THEME=.*|#GRUB_THEME=|' /etc/default/grub

grub-mkconfig -o /boot/grub/grub.cfg

echo "Theme removed. Reboot to apply."
