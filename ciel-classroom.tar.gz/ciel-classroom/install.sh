#!/bin/bash

THEME_NAME="ciel-classroom"
THEME_DIR="/boot/grub/themes/$THEME_NAME"

echo "=== Ciel Classroom GRUB Theme Installer ==="
echo

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root: sudo ./install.sh"
  exit 1
fi

# Go to the folder where this script is located
cd "$(dirname "$0")" || exit 1

echo "→ Installing theme..."
mkdir -p /boot/grub/themes
rm -rf "$THEME_DIR"
cp -r . "$THEME_DIR"

# Remove the scripts from the installed theme
rm -f "$THEME_DIR/install.sh"
rm -f "$THEME_DIR/uninstall.sh"

echo "→ Configuring GRUB..."

if grep -q "^GRUB_THEME=" /etc/default/grub; then
  sed -i "s|^GRUB_THEME=.*|GRUB_THEME=\"$THEME_DIR/theme.txt\"|" /etc/default/grub
else
  echo "GRUB_THEME=\"$THEME_DIR/theme.txt\"" >> /etc/default/grub
fi

grep -q "^GRUB_GFXMODE=" /etc/default/grub || echo 'GRUB_GFXMODE=1920x1080,auto' >> /etc/default/grub
grep -q "^GRUB_GFXPAYLOAD_LINUX=" /etc/default/grub || echo 'GRUB_GFXPAYLOAD_LINUX=keep' >> /etc/default/grub

echo "→ Updating GRUB..."
grub-mkconfig -o /boot/grub/grub.cfg

echo
echo "✓ Theme installed successfully!"
echo "Reboot to see the Ciel Classroom theme."
